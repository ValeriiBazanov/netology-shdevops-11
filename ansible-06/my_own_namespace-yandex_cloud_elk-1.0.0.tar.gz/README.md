# Ansible Collection - my_own_namespace.yandex_cloud_elk

Documentation for the collection.

Коллекция запускает модуль, который с помощью task_role создает текстовый файл на удалённом хосте по пути, определённом в параметре path, с содержимым, определённым в параметре content.
